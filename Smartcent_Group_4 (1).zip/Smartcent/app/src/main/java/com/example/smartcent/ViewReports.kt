package com.example.smartcent

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ViewReports : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var listView: ListView
    private lateinit var startDate: EditText
    private lateinit var endDate: EditText
    private lateinit var filterButton: Button
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_view_reports)

        dbHelper = DatabaseHelper(this)
        listView = findViewById(R.id.reportListView)
        startDate = findViewById(R.id.startDate)
        endDate = findViewById(R.id.endDate)
        filterButton = findViewById(R.id.filterButton)

        // Get logged-in userId from SharedPreferences
        val prefs = getSharedPreferences("UserSession", MODE_PRIVATE)
        userId = prefs.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "No user session found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Date pickers
        startDate.setOnClickListener { showDatePicker(startDate) }
        endDate.setOnClickListener { showDatePicker(endDate) }

        // Default: show all reports for this user
        loadReports(dbHelper.getExpensesForUser(userId))

        // Filter button
        filterButton.setOnClickListener {
            val start = startDate.text.toString().trim()
            val end = endDate.text.toString().trim()
            if (start.isEmpty() || end.isEmpty()) {
                Toast.makeText(this, "Please select both dates", Toast.LENGTH_SHORT).show()
            } else {
                val filtered = dbHelper.getExpensesByDateRange(userId, start, end)
                loadReports(filtered)
            }
        }
    }

    private fun showDatePicker(editText: EditText) {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                editText.setText("$day/${month + 1}/$year")
            },
            2026, 0, 1 // default values
        ).show()
    }

    private fun loadReports(expenses: List<DatabaseHelper.Expense>) {
        val totals = mutableMapOf<String, Double>()
        var grandTotal = 0.0

        for (expense in expenses) {
            totals[expense.category] = totals.getOrDefault(expense.category, 0.0) + expense.amount
            grandTotal += expense.amount
        }

        val displayList = totals.map {
            "${it.key}: R${"%.2f".format(it.value)}"
        }.toMutableList()

        // Add grand total line at the bottom
        displayList.add("Grand Total: R${"%.2f".format(grandTotal)}")

        if (displayList.isEmpty()) {
            Toast.makeText(this, "No data to display", Toast.LENGTH_SHORT).show()
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        listView.adapter = adapter
    }
}