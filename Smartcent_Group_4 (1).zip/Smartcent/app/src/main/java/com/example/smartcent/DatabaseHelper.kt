package com.example.smartcent

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "budget_tracker.db"
        private const val DATABASE_VERSION = 4
        private const val TABLE_USERS = "users"
        private const val TABLE_CATEGORIES = "categories"
        private const val TABLE_EXPENSES = "expenses"

        private const val COLUMN_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"
        private const val COLUMN_CATEGORY_NAME = "name"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Users table
        db.execSQL("""
            CREATE TABLE $TABLE_USERS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT UNIQUE,
                $COLUMN_PASSWORD TEXT
            )
        """.trimIndent())

        // Categories table
        db.execSQL("""
            CREATE TABLE $TABLE_CATEGORIES (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_CATEGORY_NAME TEXT,
                user_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES $TABLE_USERS(id)
            )
        """.trimIndent())

        // Expenses table
        db.execSQL("""
            CREATE TABLE $TABLE_EXPENSES (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                start_time TEXT,
                end_time TEXT,
                description TEXT,
                amount REAL,
                category TEXT,
                photo_uri TEXT,
                user_id INTEGER,
                FOREIGN KEY(user_id) REFERENCES $TABLE_USERS(id)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CATEGORIES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EXPENSES")
        onCreate(db)
    }

    // USER FUNCTIONS
    fun insertUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        return db.insert(TABLE_USERS, null, values) != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun getUserId(username: String): Int? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT id FROM $TABLE_USERS WHERE $COLUMN_USERNAME=?", arrayOf(username))
        val userId = if (cursor.moveToFirst()) cursor.getInt(0) else null
        cursor.close()
        return userId
    }

    //  CATEGORY FUNCTIONS
    fun insertCategory(name: String, userId: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_CATEGORY_NAME, name)
            put("user_id", userId)
        }
        return db.insert(TABLE_CATEGORIES, null, values) != -1L
    }

    fun getCategoriesForUser(userId: Int): List<String> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COLUMN_CATEGORY_NAME FROM $TABLE_CATEGORIES WHERE user_id=?",
            arrayOf(userId.toString())
        )
        val categories = mutableListOf<String>()
        while (cursor.moveToNext()) {
            categories.add(cursor.getString(0))
        }
        cursor.close()
        return categories
    }

    //  EXPENSE FUNCTIONS
    fun insertExpense(
        date: String,
        startTime: String,
        endTime: String,
        description: String,
        amount: Double,
        category: String,
        photoUri: String?,
        userId: Int
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("date", date)
            put("start_time", startTime)
            put("end_time", endTime)
            put("description", description)
            put("amount", amount)
            put("category", category)
            put("photo_uri", photoUri)
            put("user_id", userId)
        }
        return db.insert(TABLE_EXPENSES, null, values) != -1L
    }

    data class Expense(
        val date: String,
        val startTime: String,
        val endTime: String,
        val description: String,
        val amount: Double,
        val category: String,
        val photoUri: String?
    )


    //each user will have their own unique data hence this function
    fun getExpensesForUser(userId: Int): List<Expense> {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_EXPENSES WHERE user_id=?", arrayOf(userId.toString()))
        val expenses = mutableListOf<Expense>()
        while (cursor.moveToNext()) {
            expenses.add(
                Expense(
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    startTime = cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    endTime = cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                    category = cursor.getString(cursor.getColumnIndexOrThrow("category")),
                    photoUri = cursor.getString(cursor.getColumnIndexOrThrow("photo_uri"))
                )
            )
        }
        cursor.close()
        return expenses
    }

    //function I used for when I wanna filter report by the data
    fun getExpensesByDateRange(userId: Int, startDate: String, endDate: String): List<Expense> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_EXPENSES WHERE user_id=? AND date BETWEEN ? AND ? ORDER BY date ASC",
            arrayOf(userId.toString(), startDate, endDate)
        )
        val expenses = mutableListOf<Expense>()
        while (cursor.moveToNext()) {
            expenses.add(
                Expense(
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    startTime = cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    endTime = cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                    category = cursor.getString(cursor.getColumnIndexOrThrow("category")),
                    photoUri = cursor.getString(cursor.getColumnIndexOrThrow("photo_uri"))
                )
            )
        }
        cursor.close()
        return expenses
    }



    //For the tracking board on the main dashboard

    fun getTotalExpenses(userId: Int): Double {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT SUM(amount) FROM expenses WHERE user_id = ?", arrayOf(userId.toString()))
        var total = 0.0
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0)
        }
        cursor.close()
        return total
    }

    fun getBudgetGoal(userId: Int): Double {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT goal FROM budgets WHERE user_id = ?", arrayOf(userId.toString()))
        var goal = 0.0
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(0)
        }
        cursor.close()
        return goal
    }

    fun saveBudgetGoal(userId: Int, min: Double, max: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", userId)
            put("goal", min)   // store min budget
            put("max_goal", max)
        }
        val result = db.insertWithOnConflict("budgets", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return result != -1L
    }


}
