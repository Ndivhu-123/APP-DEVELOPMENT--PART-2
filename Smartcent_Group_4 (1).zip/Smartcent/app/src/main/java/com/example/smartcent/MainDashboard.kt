package com.example.smartcent

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity



class MainDashboard : AppCompatActivity() {


    private lateinit var expensesText: TextView
    private lateinit var goalsText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_dashboard)


        // Find your TextViews
        expensesText = findViewById<TextView>(R.id.expensesText)
        goalsText = findViewById<TextView>(R.id.goalsText)


        //My navigation buttons
        val addExpenseBtn = findViewById<ImageButton>(R.id.addExButton)
        val categoryBtn = findViewById<ImageButton>(R.id.category)
        val reportBtn = findViewById<ImageButton>(R.id.ViewReports)
        val budgetBtn = findViewById<ImageButton>(R.id.setGoals)
        val viewExpensesBtn = findViewById<ImageButton>(R.id.expenseListView)
        val logoutBtn = findViewById<ImageButton>(R.id.Logout)

        addExpenseBtn.setOnClickListener {
            startActivity(Intent(this, AddExpense::class.java))
        }

        categoryBtn.setOnClickListener {
            startActivity(Intent(this, AddCategory::class.java))
        }

        reportBtn.setOnClickListener {
            startActivity(Intent(this, ViewReports::class.java))
        }

        budgetBtn.setOnClickListener {
            startActivity(Intent(this, SetGoals::class.java))
        }

        logoutBtn.setOnClickListener {
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
        }


        viewExpensesBtn.setOnClickListener {
            startActivity(Intent(this, ExpenseList::class.java))
        }
    }


    override fun onResume() {
        super.onResume()

        val prefs = getSharedPreferences("SmartCentPrefs", MODE_PRIVATE)
        val totalExpenses = prefs.getFloat("TOTAL_EXPENSES", 0f)
        val budgetGoal = prefs.getFloat("BUDGET_GOAL", 0f)

        expensesText.text = String.format("Total Expenses: R%.2f", totalExpenses)
        goalsText.text = String.format("Budget Goal: R%.2f", budgetGoal)
    }
}