package com.example.smartcent

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Login : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        dbHelper = DatabaseHelper(this)

        val loginButton = findViewById<Button>(R.id.loginButton)
        val usernameEt = findViewById<EditText>(R.id.userNameEdit)
        val passwordEt = findViewById<EditText>(R.id.passwordEdit)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        loginButton.setOnClickListener {
            val username = usernameEt.text.toString().trim()
            val password = passwordEt.text.toString().trim()

            when {
                username.isEmpty() -> usernameEt.error = "Username required"
                password.isEmpty() -> passwordEt.error = "Password required"
                else -> {
                    val valid = dbHelper.checkUser(username, password)
                    if (valid) {
                        // Fetch the userId
                        val userId = dbHelper.getUserId(username)

                        if (userId != null) {
                            // Save userId in SharedPreferences so other activities can use it
                            val prefs = getSharedPreferences("UserSession", MODE_PRIVATE)
                            prefs.edit().putInt("user_id", userId).apply()
                            prefs.edit().putString("username", username).apply()

                            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, MainDashboard::class.java))
                            finish()
                        } else {
                            Toast.makeText(this, "Error fetching user ID", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
