package com.example.smartcent

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class AddCategory : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ArrayAdapter<String>
    private val categoryList = ArrayList<String>()
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_category)

        dbHelper = DatabaseHelper(this)

        // Get logged-in userId from SharedPreferences
        val prefs = getSharedPreferences("UserSession", MODE_PRIVATE)
        userId = prefs.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "No user session found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val categoryEt = findViewById<EditText>(R.id.categoryEditText)
        val addBtn = findViewById<Button>(R.id.addCategory)
        val listView = findViewById<ListView>(R.id.categoryListView)

        // Load categories for this user
        categoryList.addAll(dbHelper.getCategoriesForUser(userId))
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, categoryList)
        listView.adapter = adapter

        addBtn.setOnClickListener {
            val category = categoryEt.text.toString().trim()

            when {
                category.isEmpty() -> categoryEt.error = "Category cannot be empty"
                category.length < 3 -> categoryEt.error = "Minimum 3 characters"
                categoryList.contains(category) -> categoryEt.error = "Category already exists"
                else -> {
                    val success = dbHelper.insertCategory(category, userId)
                    if (success) {
                        categoryList.clear()
                        categoryList.addAll(dbHelper.getCategoriesForUser(userId))
                        adapter.notifyDataSetChanged()
                        categoryEt.text.clear()
                        Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Error adding category", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
