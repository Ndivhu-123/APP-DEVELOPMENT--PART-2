package com.example.smartcent

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SetGoals : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_set_goals)


        val minEt = findViewById<EditText>(R.id.minimumBudget)
        val maxEt = findViewById<EditText>(R.id.maxBudget)
        val saveBtn = findViewById<Button>(R.id.SaveBudgetButton)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        saveBtn.setOnClickListener {

            val min = minEt.text.toString().trim()
            val max = maxEt.text.toString().trim()

            when {
                min.isEmpty() -> {
                    minEt.error = "Enter minimum amount"
                }

                max.isEmpty() -> {
                    maxEt.error = "Enter maximum amount"
                }

                min.toDoubleOrNull() == null -> {
                    minEt.error = "Invalid number"
                }

                max.toDoubleOrNull() == null -> {
                    maxEt.error = "Invalid number"
                }

                min.toDouble() < 0 -> {
                    minEt.error = "Cannot be negative"
                }

                max.toDouble() <= 0 -> {
                    maxEt.error = "Must be greater than 0"
                }

                min.toDouble() > max.toDouble() -> {
                    maxEt.error = "Max must be greater than Min"
                }

                else -> {
                    Toast.makeText(this, "Budget goals saved (mock)", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
