package com.example.smartcent

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity



class MainDashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_dashboard)


        val addExpenseBtn = findViewById<Button>(R.id.addExButton)
        val categoryBtn = findViewById<Button>(R.id.category)
        val reportBtn = findViewById<Button>(R.id.ViewReports)
        val budgetBtn = findViewById<Button>(R.id.setGoals)
        val viewExpensesBtn = findViewById<Button>(R.id.expenseListView)
        val logoutBtn = findViewById<Button>(R.id.Logout)

        addExpenseBtn.setOnClickListener {
            startActivity(Intent(this, AddExpense::class.java))
        }

        categoryBtn.setOnClickListener {
            startActivity(Intent(this, AddCategory::class.java))
        }

        reportBtn.setOnClickListener {
            startActivity(Intent(this, ViewReports::class.java))
        }

        budgetBtn.setOnClickListener {
            startActivity(Intent(this, SetGoals::class.java))
        }

        logoutBtn.setOnClickListener {
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, Login::class.java)
            startActivity(intent)
            finish()
        }



        viewExpensesBtn.setOnClickListener {
            startActivity(Intent(this, ExpenseList::class.java))
        }

    }
}